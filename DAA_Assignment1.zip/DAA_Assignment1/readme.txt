Group Details:
1. Abhinav Verma 2020A7PS1093H
2. Anupam Singh 2020A7PS0203H
3. Darshan Chandak 2020A7PS2085H
4. Sahil Bhore 2020A7PS2065H


How to run?

1. g++ main.cpp -o main
2. ./main

How to visualize?

1. python visualize.py
