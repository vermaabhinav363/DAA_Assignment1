var namespaces_dup =
[
    [ "visualize", "namespacevisualize.html", [
      [ "draw", "namespacevisualize.html#adcb2f8613b1103dc0e69feab78cec364", null ],
      [ "list", "namespacevisualize.html#a89bc4494c1cd47877d8f6a7ead1396fb", null ],
      [ "sum_x", "namespacevisualize.html#a4c8cf2c4b4bbf8d3e61925c7d09ee653", null ],
      [ "sum_y", "namespacevisualize.html#aa0b4d32866c19a1e1174d93e6a19da6e", null ]
    ] ]
];