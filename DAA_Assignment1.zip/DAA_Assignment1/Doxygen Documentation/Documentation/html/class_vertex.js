var class_vertex =
[
    [ "Vertex", "class_vertex.html#af7b707c845351522267c2c6245fa6ca6", null ],
    [ "get_coordinates", "class_vertex.html#ade6aab283db1c6a4c0886e04921cce98", null ],
    [ "get_incidentEdge", "class_vertex.html#a66bd18e3ab1a953f81e3c15f99fcf634", null ],
    [ "set_incidentEdge", "class_vertex.html#af0c421646f594265ae30c3c60883f156", null ]
];