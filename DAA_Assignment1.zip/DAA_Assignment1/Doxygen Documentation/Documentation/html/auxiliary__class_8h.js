var auxiliary__class_8h =
[
    [ "AuxiliaryClass", "class_auxiliary_class.html", null ],
    [ "clockwise_angle", "auxiliary__class_8h.html#a622317f769a90cb32e251ce2345882e7", null ],
    [ "isVectorToRightOfLine", "auxiliary__class_8h.html#a82b5d6bcfe56b24756e05becebd2b9b3", null ],
    [ "isVertexInsidePolygon", "auxiliary__class_8h.html#aa4b2db8eeab113dbc04df165b0024593", null ]
];