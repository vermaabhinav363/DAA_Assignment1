var searchData=
[
  ['ver_5fcount_0',['ver_count',['../dcel_8h.html#a164771cc4db82cdad7e96d94f31897e1',1,'dcel.h']]],
  ['vertices_1',['vertices',['../class_dcel.html#aa423d8837fcb6a464d9878dfb331e3dc',1,'Dcel']]]
];
