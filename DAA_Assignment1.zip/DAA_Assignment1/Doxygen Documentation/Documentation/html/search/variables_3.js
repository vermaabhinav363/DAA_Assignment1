var searchData=
[
  ['sum_5fx_0',['sum_x',['../namespacevisualize.html#a4c8cf2c4b4bbf8d3e61925c7d09ee653',1,'visualize']]],
  ['sum_5fy_1',['sum_y',['../namespacevisualize.html#aa0b4d32866c19a1e1174d93e6a19da6e',1,'visualize']]]
];
