var searchData=
[
  ['face_5fcount_0',['face_count',['../dcel_8h.html#a677eefc855dffc6a8d8fa1837fe0d314',1,'dcel.h']]],
  ['faces_1',['faces',['../class_dcel.html#acb5fadbf0d20628b68959419fa51a7df',1,'Dcel']]]
];
