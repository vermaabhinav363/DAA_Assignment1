var searchData=
[
  ['removal_5fedges_0',['removal_edges',['../class_auxiliary_class.html#ac2089c19eb2805e0d9e218b33ed70e86',1,'AuxiliaryClass']]],
  ['remove_5fvertex_1',['remove_vertex',['../class_dcel.html#acf3bbca734c0a4d24429fd008a910f52',1,'Dcel']]],
  ['replace_2',['replace',['../class_dcel.html#ab4469f81be4d96142689eb2d03281b34',1,'Dcel']]]
];
