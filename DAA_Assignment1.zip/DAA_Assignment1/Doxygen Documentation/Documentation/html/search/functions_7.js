var searchData=
[
  ['main_0',['main',['../main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]],
  ['merging_1',['merging',['../class_merging.html#a0b3683098e1b5d526ea4b94df8a81131',1,'Merging']]]
];
