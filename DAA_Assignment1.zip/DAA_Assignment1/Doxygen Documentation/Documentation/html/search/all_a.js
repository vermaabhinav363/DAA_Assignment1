var searchData=
[
  ['obtain_5fnotches_0',['obtain_notches',['../class_auxiliary_class.html#a650238ba84be71e7b570b7c6971315ea',1,'AuxiliaryClass']]]
];
