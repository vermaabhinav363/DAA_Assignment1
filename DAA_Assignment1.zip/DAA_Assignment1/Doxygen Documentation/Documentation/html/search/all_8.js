var searchData=
[
  ['main_0',['main',['../main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]],
  ['main_2ecpp_1',['main.cpp',['../main_8cpp.html',1,'']]],
  ['merging_2',['Merging',['../class_merging.html',1,'']]],
  ['merging_3',['merging',['../class_merging.html#a0b3683098e1b5d526ea4b94df8a81131',1,'Merging']]],
  ['merging_2eh_4',['merging.h',['../merging_8h.html',1,'']]]
];
