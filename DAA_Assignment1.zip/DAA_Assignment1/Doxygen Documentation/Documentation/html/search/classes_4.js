var searchData=
[
  ['merging_0',['Merging',['../class_merging.html',1,'']]]
];
