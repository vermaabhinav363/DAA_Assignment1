var merging_8h =
[
    [ "Merging", "class_merging.html", null ],
    [ "clockwise_angle_merging", "merging_8h.html#aa7877dfefa6aa65eaa987c6a6c82046b", null ],
    [ "get_angle_merging", "merging_8h.html#a5ca5e0dfa9ac095e397a07a534b86a15", null ]
];