var class_face =
[
    [ "Face", "class_face.html#a559f8d1751de5affeacc35830cddcc14", null ],
    [ "get_edge", "class_face.html#a051870bd7b7ac98e98c8917d26a76afb", null ],
    [ "set_edge", "class_face.html#a6b70b5842c77e58808550d73bddcc338", null ]
];