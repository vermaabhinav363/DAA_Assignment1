var annotated_dup =
[
    [ "Algorithm1", "class_algorithm1.html", null ],
    [ "AuxiliaryClass", "class_auxiliary_class.html", null ],
    [ "Dcel", "class_dcel.html", "class_dcel" ],
    [ "Edge", "class_edge.html", "class_edge" ],
    [ "Face", "class_face.html", "class_face" ],
    [ "Merging", "class_merging.html", null ],
    [ "Vertex", "class_vertex.html", "class_vertex" ],
    [ "VertexDecomposition", "class_vertex_decomposition.html", null ]
];