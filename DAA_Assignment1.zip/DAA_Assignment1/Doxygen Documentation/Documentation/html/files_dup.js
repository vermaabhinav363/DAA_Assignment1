var files_dup =
[
    [ "Code", "dir_23fdee2f6995db16c755697cdf620cf4.html", "dir_23fdee2f6995db16c755697cdf620cf4" ],
    [ "Resource", "dir_9ddeeb997bc2af5957d3bd0d4b3d2f72.html", null ]
];