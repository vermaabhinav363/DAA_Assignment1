var dir_23fdee2f6995db16c755697cdf620cf4 =
[
    [ "algo1.h", "algo1_8h.html", "algo1_8h" ],
    [ "auxiliary_class.h", "auxiliary__class_8h.html", "auxiliary__class_8h" ],
    [ "dcel.h", "dcel_8h.html", "dcel_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "merging.h", "merging_8h.html", "merging_8h" ],
    [ "VDP.h", "_v_d_p_8h.html", "_v_d_p_8h" ],
    [ "visualize.py", "visualize_8py.html", "visualize_8py" ]
];